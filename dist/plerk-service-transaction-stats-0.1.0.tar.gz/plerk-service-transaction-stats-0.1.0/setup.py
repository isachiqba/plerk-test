# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['plerk',
 'plerk.service.transaction.stats',
 'plerk.service.transaction.stats.management.commands',
 'plerk.service.transaction.stats.migrations',
 'plerk.service.transaction.stats.models',
 'plerk.service.transaction.stats.viewsets']

package_data = \
{'': ['*']}

install_requires = \
['django>=4.0,<5.0',
 'djangorestframework>=3.13.0,<4.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'psycopg2-binary>=2.9.2,<3.0.0',
 'pygments>=2.10.0,<3.0.0',
 'pytz>=2021.3,<2022.0',
 'wasabi>=0.9.0,<0.10.0']

setup_kwargs = {
    'name': 'plerk-service-transaction-stats',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Foo\n\n## Deployment to GCP\n\n```sh\n# Create an small VM instance with Container-Optimized OS as the base system.\ngcloud compute instances create plerk-test \\\n  ... \\\n  --machine-type=e2-micro \\\n  --tags=http-server \\\n  ...\n\n# SSH into the machine\ngcloud beta compute ssh plerk-test\n\n# clone the repo\ngit clone https://github.com/isachiqba/plerk-test\ncd plerk-test\n\n#\n./deploy/docker-compose.sh\n```\n',
    'author': 'ixa64',
    'author_email': 'isachiqba@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
