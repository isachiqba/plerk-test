from django import apps


class AppConfig(apps.AppConfig):

  label = "pststats"

  name = "plerk.service.transaction.stats"
