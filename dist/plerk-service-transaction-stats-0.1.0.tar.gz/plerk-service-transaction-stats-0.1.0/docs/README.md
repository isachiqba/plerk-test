# Foo

## Deployment to GCP

```sh
# Create an small VM instance with Container-Optimized OS as the base system.
gcloud compute instances create plerk-test \
  ... \
  --machine-type=e2-micro \
  --tags=http-server \
  ...

# SSH into the machine
gcloud beta compute ssh plerk-test

# clone the repo
git clone https://github.com/isachiqba/plerk-test
cd plerk-test

#
./deploy/docker-compose.sh
```
