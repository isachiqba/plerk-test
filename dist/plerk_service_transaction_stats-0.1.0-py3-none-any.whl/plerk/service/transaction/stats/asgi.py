from os import environ
from django.core.asgi import get_asgi_application

environ.setdefault("DJANGO_SETTINGS_MODULE", "plerk.service.transaction.stats.conf")

application = get_asgi_application()
